<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h3>โปรแกรมที่ประกาศตัวแปรอาร์เรย์</h3>
    <h3>Name: สหรัถ อินต๊ะวิรา ID: 65122250014</h3>
    <hr>

    <?php
    $fruits = array(
        "apple", # List Array
        "papaya",
        "banana",
        "orange",
        "watermelon"
    );

    echo "<pre>";
    print_r($fruits);
    echo "</pre>";
    ?>
</body>

</html>