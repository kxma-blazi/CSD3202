<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>เขียนโปรแกรมที่ประกาศตัวแปร 3 ชนิด </h3>
    <h3>Name: สหรัถ อินต๊ะวิรา ID: 65122250014</h3>
    <hr>
    
    <?php
    $name = "สหรัถ อินต๊ะวิรา"; # String
    $age = 21; # Int
    $height = 1.79; # Float

    echo "Name: $name <br>";
    echo "Age: $age <br>";
    echo "Height: $height";
    ?>
</body>
</html>
