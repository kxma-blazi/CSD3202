<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>โปรแกรมที่ตรวจสอบว่าผู้ใช้ป้อนข้อมูลในฟอร์มครบถ้วนหรือไม่ </h3>
    <h3>Name: สหรัถ อินต๊ะวิรา ID: 65122250014</h3>
    <hr>
    
    <form action="work5_13.php" method="post">
        <label for="name">ชื่อ: </label>
        <input type="text" name="name" id="name">
        <br>
        <label for="surname">นามสกุล: </label>
        <input type="text" name="surname" id="surname">
        <br>
        <label for="id">รหัสนักศึกษา: </label>
        <input type="text" name="id" id="id">
        <br>
        <input type="submit" value="ยืนยัน">
    </form>
</body>
</html>