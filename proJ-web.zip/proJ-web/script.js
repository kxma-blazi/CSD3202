// JavaScript code can go here for interactivity (if needed in the future)
console.log("Movie website loaded");
