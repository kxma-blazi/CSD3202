<?php
session_start();

// ตรวจสอบว่าผู้ใช้ได้ล็อกอินหรือยัง
if (!isset($_SESSION['username'])) {
    // ถ้ายังไม่ได้ล็อกอินให้ส่งผู้ใช้กลับไปที่หน้า login
    header("Location: login.html");
    exit();
}
?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Reservation</title>
    <link href="round.css" rel="stylesheet">
    <link href="Search.css" rel="stylesheet">
    




    <link rel="shortcut icon" type="image/x-icon" href="Photo/preview (2).png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    
    <nav class="navbar sticky-top navbar-expand-sm navbar-light " style="background-color:  #333;" >
        <div class="container" style="background-color: #333;">
            <a href="index.html" class="navbar-brand">
                <!-- Logo -->
                <img src="img/Logo1.png" height="70" width="80" alt="" style="border-radius: 100%;">

            </a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar1">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- เมนูนำทางหลัก -->
            <div id="navbar1" class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <!-- ลิงก์ไปยังหน้าจองหนัง -->
                    <li class="nav-item">
                        <a href="index.html" class="nav-link" style="color: beige; margin-right: 40px ;"><B>HOME</B></a>
                    </li>
                    <!-- เมนูแบบดร็อปดาวน์สำหรับหมวดหมู่หนัง -->
                    <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" style="color: beige; margin-right: 40px;" href="#"
                            role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <B>Movies </B>
                        </a>
                        <ul class=" dropdown-content" style="margin-left: -40px;background-color: #333;">
                            <a class="dropdown-item" href="Action.html">หนังแอคชั่น Action</a>
                            <a class="dropdown-item" href="adventure.html">ผจญภัย Adventure</a>
                            <a class="dropdown-item" href="horror.html">หนังสยองขวัญ Horror</a>
                            <a class="dropdown-item" href="ASci-fi.html">วิทยาศาสตร์ Sci-fi</a>
                            
                                <hr class="dropdown-divider">
                            
                            <a class="dropdown-item" href="#"></a>
                        </ul>
                    </li>
                    <!-- ลิงก์ไปยังหน้าจองหนัง -->
                    <li class="nav-item">
                        <a href="./Gallery.html" class="nav-link"
                            style="color: beige; margin-right: 50px;"><B>Reservation round </B></a>
                    </li>



                    <!-- กล่องค้นหา -->
                    <div class="search" style="margin-right: 200px;">
                        <div class="search-box">
                            <div class="search-field">
                                <input placeholder="Search..." class="input" type="text">
                                <div class="search-box-icon">
                                    <button class="btn-icon-content">
                                        <i class="search-icon">
                                            <svg xmlns="://www.w3.org/2000/svg" version="1.1" viewBox="0 0 512 512">
                                                <path
                                                    d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"
                                                    fill="#fff"></path>
                                            </svg>
                                        </i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>



                </ul>


            </div>
            <a href="login.html" class="navbar-brand">
                <!-- Logo -->
                <img src="img/user(1).png" height="50" width="50" alt=""
                    style="border-radius: 100%;margin-bottom: px; ">

            </a>

            
        
        
        </div>
        </div>
    </nav><br ><br >

    <h1>Room Reservation</h1>

    <div class="container">
        <!-- Room 1 -->
        <div class="room">
            <span>Big room 1:</span>
            <span class="status available" id="status-room-1"style="margin-left: 15px;">Available</span>
            <button id="room-1-btn" onclick="showReservationForm('1')" style="margin-left: 800px;">Reserve</button>
            <button class="cancel-btn" id="room-1-cancel-btn" onclick="cancelRoom('1')" style="display: none;">Cancel</button>
            
            <div class="details" id="details-room-1"></div>
        </div>

        <!-- Room 2 -->
        <div class="room">
            <span>Big room 2:</span>
            <span class="status available" id="status-room-2"style="margin-left: 15px;">Available</span>
            <button id="room-2-btn" onclick="showReservationForm('2') "style="margin-left: 800px;" >Reserve</button>
            <button class="cancel-btn" id="room-2-cancel-btn" onclick="cancelRoom('2')" style="display: none;">Cancel</button>

            <div class="details" id="details-room-2"></div>
        </div>

        <!-- Room 3 -->
        <div class="room">
            <span>small room 1:</span>
            <span class="status available" id="status-room-3">Available</span>
            <button id="room-3-btn" onclick="showReservationForm('3')"style="margin-left: 800px;">Reserve</button>
            <button class="cancel-btn" id="room-3-cancel-btn" onclick="cancelRoom('3')" style="display: none;">Cancel</button>

            <div class="details" id="details-room-3"></div>
        </div>

         <!-- Room 4 -->
         <div class="room">
            <span>small room 2:</span>
            <span class="status available" id="status-room-3">Available</span>
            <button id="room-3-btn" onclick="showReservationForm('3')"style="margin-left: 800px;">Reserve</button>
            <button class="cancel-btn" id="room-3-cancel-btn" onclick="cancelRoom('3')" style="display: none;">Cancel</button>

            <div class="details" id="details-room-3"></div>
        </div>

         <!-- Room 5 -->
         <div class="room">
            <span>small room 3:</span>
            <span class="status available" id="status-room-3">Available</span>
            <button id="room-3-btn" onclick="showReservationForm('3')"style="margin-left: 800px;">Reserve</button>
            <button class="cancel-btn" id="room-3-cancel-btn" onclick="cancelRoom('3')" style="display: none;">Cancel</button>

            <div class="details" id="details-room-3"></div>
        </div>

         <!-- Room 6 -->
         <div class="room">
            <span>small room 4:</span>
            <span class="status available" id="status-room-3">Available</span>
            <button id="room-3-btn" onclick="showReservationForm('3')"style="margin-left: 800px;">Reserve</button>
            <button class="cancel-btn" id="room-3-cancel-btn" onclick="cancelRoom('3')" style="display: none;">Cancel</button>

            <div class="details" id="details-room-3"></div>
        </div>
        <!-- Reset Button -->
    </div>

    <!-- Reservation Form (Popup) -->
    <div id="reservation-form" style="display: none;margin-left: 400px;">
        <h2>Reserve Room</h2>

        <div class="input-field">
            <label for="movie-name">Movie Name:</label>
            <input type="text" id="movie-name" required>
        </div>

        <div class="input-field">
            <label for="date">Date:</label>
            <input type="date" id="date" required>
        </div>

        <div class="input-field">
            <label for="time">Time:</label>
            <input type="time" id="time" required>
        </div>

        

        <button onclick="reserveRoom()">Confirm Reservation</button>
        <button onclick="closeForm()">Cancel</button>
    </div>

    <script>
        let selectedRoom = '';

        function showReservationForm(roomNumber) {
            selectedRoom = roomNumber;
            document.getElementById('reservation-form').style.display = 'block';
        }

        function closeForm() {
            document.getElementById('reservation-form').style.display = 'none';
        }

        function reserveRoom() {
            const movieName = document.getElementById('movie-name').value;
            const date = document.getElementById('date').value;
            const time = document.getElementById('time').value;

            if (!movieName || !date || !time ) {
                alert("Please fill in all fields.");
                return;
            }

            // เปลี่ยนสถานะของห้องที่เลือกเป็น Reserved
            document.getElementById('status-room-' + selectedRoom).textContent = 'Reserved';
            document.getElementById('status-room-' + selectedRoom).classList.remove('available');
            document.getElementById('status-room-' + selectedRoom).classList.add('reserved');
            document.getElementById('room-' + selectedRoom + '-btn').disabled = true;
            document.getElementById('room-' + selectedRoom + '-cancel-btn').style.display = 'inline-block';

            // แสดงรายละเอียดการจอง
            document.getElementById('details-room-' + selectedRoom).innerHTML = `
                <strong>Movie:</strong> ${movieName}<br>
                <strong>Date:</strong> ${date}<br>
                <strong>Time:</strong> ${time}<br>`;

            closeForm();
        }

        function cancelRoom(roomNumber) {
            // เปลี่ยนสถานะของห้องกลับเป็น Available
            document.getElementById('status-room-' + roomNumber).textContent = 'Available';
            document.getElementById('status-room-' + roomNumber).classList.remove('reserved');
            document.getElementById('status-room-' + roomNumber).classList.add('available');
            document.getElementById('room-' + roomNumber + '-btn').disabled = false;
            document.getElementById('room-' + roomNumber + '-cancel-btn').style.display = 'none';

            // ลบรายละเอียดการจอง
            document.getElementById('details-room-' + roomNumber).innerHTML = '';
        }

        function resetRooms() {
            // รีเซ็ตสถานะของห้องทั้งหมดเป็น Available
            for (let i = 1; i <= 3; i++) {
                document.getElementById('status-room-' + i).textContent = 'Available';
                document.getElementById('status-room-' + i).classList.remove('reserved');
                document.getElementById('status-room-' + i).classList.add('available');
                document.getElementById('room-' + i + '-btn').disabled = false;
                document.getElementById('room-' + i + '-cancel-btn').style.display = 'none';
                document.getElementById('details-room-' + i).innerHTML = '';
            }
        }
    </script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

</body>
</html>
