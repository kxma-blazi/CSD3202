<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'user_db');

if ($conn->connect_error) {
    die('Connection Failed : '.$conn->connect_error);
}

// Handling the signup form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encrypting the password
    $student_id = $_POST['student_id'];
    
    // SQL query to insert data
    $sql = "INSERT INTO users (username, password, student_id) VALUES ('$username', '$password', '$student_id')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Signup successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>
