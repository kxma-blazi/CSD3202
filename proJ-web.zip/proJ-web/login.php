<?php 
session_start(); // เริ่ม session

// เชื่อมต่อกับฐานข้อมูล
$conn = new mysqli("localhost", "root", "", "user_db");

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // ตรวจสอบว่ามีผู้ใช้อยู่ในฐานข้อมูลหรือไม่
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // รับข้อมูลผู้ใช้
        $row = $result->fetch_assoc();
        // ตรวจสอบรหัสผ่าน
        if (password_verify($password, $row['password'])) {
            // ตั้งค่า session
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $row['role']; // เก็บ role ของผู้ใช้ใน session

            // ตรวจสอบ role ของผู้ใช้
            if ($row['role'] == 'admin') {
                // หากเป็น admin ให้ไปยังหน้า admin
                header("Location: admin_dashboard.php");
            } else {
                // หากไม่ใช่ admin ให้ไปยังหน้าทั่วไป
                header("Location: round.php");
            }
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "Invalid username.";
    }
}

$conn->close();
?>
