<?php
session_start();

// ตรวจสอบว่าผู้ใช้งานเป็น Admin หรือไม่
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php"); // เปลี่ยนเส้นทางไปยังหน้าล็อกอินหากไม่ใช่ admin
    exit();
}

// เชื่อมต่อกับฐานข้อมูล
$conn = new mysqli("localhost", "root", "", "user_db");

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ฟังก์ชันลบผู้ใช้
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "User deleted successfully.";
    } else {
        echo "Failed to delete user.";
    }
}

// ดึงข้อมูลผู้ใช้ทั้งหมด
$sql = "SELECT id, username, role FROM users";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        a {
            color: red;
        }
    </style>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <h2>Manage Users</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Role</th>
            <th>Action</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            // แสดงข้อมูลผู้ใช้
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['username'] . "</td>";
                echo "<td>" . $row['role'] . "</td>";
                echo "<td><a href='admin_dashboard.php?delete=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this user?\");'>Delete</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No users found</td></tr>";
        }
        ?>
    </table>

    <p><a href="logout.php">Logout</a></p>
</body>
</html>

<?php
$conn->close();
?>
